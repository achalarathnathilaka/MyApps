package io.springbootstarter.course;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import io.springbootstarter.topic.Topic;

@Entity
@Table(name = "course")
public class Course {

	@Id
	private String id;
	private String name;
	private String description;
	//@ManyToOne(optional = true)
	// @OneToOne(optional=false,cascade=CascadeType.ALL,
	// mappedBy="course",targetEntity=Topic.class)
	// @OneToOne(optional=false)
	@ManyToOne
	//@JoinColumn(name="TOPIC_ID")
	private Topic topic;

//	@OneToMany(mappedBy = "course", targetEntity = Topic.class, fetch = FetchType.EAGER)
//	private Collection topic2;
//
//	public Collection getTopic2() {
//		return topic2;
//	}
//
//	public void setTopic2(Collection topic2) {
//		this.topic2 = topic2;
//	}

	public Topic getTopic() {
		return topic;
	}

	public void setTopic(Topic topic) {
		this.topic = topic;
	}

	public Course() {
	}

	public Course(String id, String name, String description, String topicId) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.topic = new Topic(topicId, "", "");

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
