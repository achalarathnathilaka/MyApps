package io.springbootstarter.course;

import java.util.List;

import org.hibernate.annotations.Parameter;
import org.jboss.logging.Param;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface CourseRepository  extends CrudRepository<Course,String>{

	List<Course> findByTopicId(String topicId);
	
	

	
	//public List<Course> findByTopicId(String topicId); 
	
//	@Query("from Auction a join a.category c where c.name=:categoryName")
//	public Iterable<Course> findByCategory( String categoryName);
	
}
