package io.springbootstarter.user;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "user")
public class User {  
	
	private String unId;
	


private String uname;  
private String upass;  
private String uemail; 

@Id
public String getUnId() {
	return unId;
}

public void setUnId(String unId) {
	this.unId = unId;
}
  
public String getUname() {  
    return uname;  
}  
  
public void setUname(String uname) {  
    this.uname = uname;  
}  
  
public String getUpass() {  
    return upass;  
}  
  
public void setUpass(String upass) {  
    this.upass = upass;  
}  
  
public String getUemail() {  
    return uemail;  
}  
  
public void setUemail(String uemail) {  
    this.uemail = uemail;  
}  
  
}  