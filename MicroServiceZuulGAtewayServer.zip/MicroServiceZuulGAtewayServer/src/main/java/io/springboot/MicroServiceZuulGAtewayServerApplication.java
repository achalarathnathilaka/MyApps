package io.springboot;





@SpringBootApplication
public class MicroServiceZuulGAtewayServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiceZuulGAtewayServerApplication.class, args);
	}
}
